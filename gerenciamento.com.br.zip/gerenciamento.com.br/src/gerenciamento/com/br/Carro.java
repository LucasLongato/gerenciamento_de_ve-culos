package gerenciamento.com.br;

public class Carro extends Veiculo{
	
	private int NumPortas;
	
	public Carro() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public int getNumPortas() {
		return NumPortas;
	}

	public void setNumPortas(int numPortas) {
		NumPortas = numPortas;
	}
}
