package gerenciamento.com.br;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ArquivoArmazentamento implements Armazenamento {

    private static final String ARQUIVO_CSV = "veiculos.csv";

    public ArquivoArmazentamento() {
        // Verifica se o arquivo existe e cria um novo se não existir
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(ARQUIVO_CSV, true));
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
            // Lidar com exceções de arquivo aqui
        }
    }

    @Override
    public void AdicionaVeiculo(Veiculo v) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(ARQUIVO_CSV, true))) {
            // Calcular o próximo ID disponível
            int proximoId = ProximoIdDisponivel();

            // Formatar os dados do veículo como uma linha CSV com o próximo ID disponível
            String linhaCSV = String.format("%d,%s,%s,%s,%.2f\n", proximoId, v.getModelo(), v.getMarca(), v.getAno_Fabric(), v.getPreco());

            // Escrever a linha no arquivo CSV
            writer.write(linhaCSV);
        } catch (IOException e) {
            e.printStackTrace();
            // Lidar com exceções de arquivo aqui
        }
    }
    
    @Override
    public void RecuperaVeiculo(int id) {
        try (BufferedReader reader = new BufferedReader(new FileReader(ARQUIVO_CSV))) {
            String linha;
            while ((linha = reader.readLine()) != null) {
                String[] partes = linha.split(",");
                if (partes.length > 0) {
                    int veiculoId = Integer.parseInt(partes[0]);
                    if (veiculoId == id) {
                        String modelo = partes[1];
                        String marca = partes[2];
                        String anoFabric = partes[3];
                        double preco = Double.parseDouble(partes[4]);

                        // Imprime as informações do veículo encontrado
                        System.out.println("Veículo encontrado:");
                        System.out.println("ID: " + veiculoId);
                        System.out.println("Modelo: " + modelo);
                        System.out.println("Marca: " + marca);
                        System.out.println("Ano de Fabricação: " + anoFabric);
                        System.out.println("Preço: " + preco);
                        System.out.println("--------------------");
                        return; // Sai do método após encontrar o veículo
                    }
                }
            }
            // Se chegou aqui, o veículo com o ID especificado não foi encontrado
            System.out.println("Veículo com ID " + id + " não encontrado.");
        } catch (IOException e) {
            e.printStackTrace();
            // Lidar com exceções de arquivo aqui
        }
    }

    @Override
    public void ListarVeiculos() {
        try (BufferedReader reader = new BufferedReader(new FileReader(ARQUIVO_CSV))) {
            String linha;
            while ((linha = reader.readLine()) != null) {
                String[] partes = linha.split(",");
                
                    int id = Integer.parseInt(partes[0]);
                    String modelo = partes[1];
                    String marca = partes[2];
                    String anoFabric = partes[3];
                    double preco = Double.parseDouble(partes[4]);

                    // Imprime as informações do veículo
                    System.out.println("ID: " + id);
                    System.out.println("Veículo:");
                    System.out.println("Modelo: " + modelo);
                    System.out.println("Marca: " + marca);
                    System.out.println("Ano de Fabricação: " + anoFabric);
                    System.out.println("Preço: " + preco);
                    System.out.println("--------------------");
                
            }
        } catch (IOException e) {
            e.printStackTrace();
            // Lidar com exceções de arquivo aqui
        }
    }

    


    // Método auxiliar para calcular o próximo ID disponível
    private int ProximoIdDisponivel() {
        int proximoId = 1;
        try (BufferedReader reader = new BufferedReader(new FileReader(ARQUIVO_CSV))) {
            String linha;
            while ((linha = reader.readLine()) != null) {
                String[] partes = linha.split(",");
                if (partes.length > 0) {
                    int veiculoId = Integer.parseInt(partes[0]);
                    if (veiculoId >= proximoId) {
                        proximoId = veiculoId + 1;
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            // Lidar com exceções de arquivo aqui
        }
        return proximoId;
    }
}
