package gerenciamento.com.br;

import java.sql.Connection;

public interface Armazenamento {
	public void AdicionaVeiculo(Veiculo v);
	public void RecuperaVeiculo(int id);
	public void ListarVeiculos();
	
}
