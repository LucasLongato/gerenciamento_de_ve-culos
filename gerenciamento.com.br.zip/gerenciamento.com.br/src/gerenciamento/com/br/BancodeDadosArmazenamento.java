package gerenciamento.com.br;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class BancodeDadosArmazenamento implements Armazenamento {

	private static final String URL = "jdbc:mysql://localhost/Veiculos?useSSL=false&allowPublicKeyRetrieval=true";
	private static final String USUARIO = "root";
	private static final String SENHA = "123ert123";



    public BancodeDadosArmazenamento() {
        try {
            Connection connection = DriverManager.getConnection(URL, USUARIO, SENHA);
            Statement statement = connection.createStatement();
            
            // Criar a tabela veiculos se ela não existir
            String createTableSQL = "CREATE TABLE IF NOT EXISTS veiculos1 (id INT AUTO_INCREMENT PRIMARY KEY, modelo VARCHAR(255), marca VARCHAR(255), ano INT, preco Double)";
            statement.executeUpdate(createTableSQL);
            
            statement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
            // Lidar com exceções de banco de dados aqui
        }
    }
    

    @Override
    public void AdicionaVeiculo(Veiculo v) {
        try {
            Connection connection = DriverManager.getConnection(URL,USUARIO,SENHA);
            String sql = "INSERT INTO veiculos1 (modelo, marca, ano,Preco) VALUES (?, ?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, v.getModelo());
            preparedStatement.setString(2, v.getMarca());
            preparedStatement.setString(3, v.getAno_Fabric());
            preparedStatement.setDouble(4, v.getPreco());
                        
            
            preparedStatement.executeUpdate();
            
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
            // Lidar com exceções de banco de dados aqui
        }
    }

    @Override
    public void RecuperaVeiculo(int id) {
        try (Connection connection = DriverManager.getConnection(URL, USUARIO, SENHA)){
            String sql = "SELECT * FROM veiculos1 WHERE id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, id);

            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int veiculoId = resultSet.getInt("id");
                String modelo = resultSet.getString("modelo");
                String marca = resultSet.getString("marca");
                int ano = resultSet.getInt("ano");
                double preco = resultSet.getDouble("preco");

                // Imprima as informações do veículo
                System.out.print("Dados do ceiculo cadastrado:");
                System.out.println("ID: " + veiculoId);
                System.out.println("Modelo: " + modelo);
                System.out.println("Marca: " + marca);
                System.out.println("Ano: " + ano);
                System.out.println("Preço: " + preco);
                System.out.println("--------------------");
            }

            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
            // Lidar com exceções de banco de dados aqui
        }
    }
    
    public void ListarVeiculos() {
        try (Connection connection = DriverManager.getConnection(URL, USUARIO, SENHA)) {
            String sql = "SELECT * FROM veiculos1";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String modelo = resultSet.getString("modelo");
                String marca = resultSet.getString("marca");
                int ano = resultSet.getInt("ano");
                double preco = resultSet.getDouble("preco");

                //APresenta as informaçoes na tela
                System.out.println("ID: " + id);
                System.out.println("Modelo: " + modelo);
                System.out.println("Marca: " + marca);
                System.out.println("Ano: " + ano);
                System.out.println("Preço: " + preco);
                System.out.println("--------------------");
            }

            preparedStatement.close();
        } catch (SQLException e) {
            e.printStackTrace();
            // Lidar com exceções de banco de dados aqui
        }
    }

}
