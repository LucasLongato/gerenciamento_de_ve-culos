package gerenciamento.com.br;

public class Veiculo {
	private String Marca;
	private String Modelo;
	private String Ano_Fabric;
	private double Preco;
	
	public String getMarca() {
		return Marca;
	}
	public void setMarca(String marca) {
		Marca = marca;
	}
	public String getModelo() {
		return Modelo;
	}
	public void setModelo(String modelo) {
		Modelo = modelo;
	}
	public String getAno_Fabric() {
		return Ano_Fabric;
	}
	public void setAno_Fabric(String ano_Fabric) {
		Ano_Fabric = ano_Fabric;
	}
	public double getPreco() {
		return Preco;
	}
	public void setPreco(double preco) {
		Preco = preco;
	}
	
	
}
