package gerenciamento.com.br;

import Banco.Armazenamento;

public class Concessionaria {
	 private Armazenamento armazenamento;

	    public Concessionaria(Armazenamento armazenamento) {
	        this.armazenamento = armazenamento;
	    }

	    public void AdicionaVeiculoAoEstoque(Veiculo v) {
	        armazenamento.AdicionaVeiculo(v);
	    }

	    public void RecuperaInformacoesVeiculo(int id) {
	        armazenamento.RecuperaVeiculo(id);
	    }

	    public void ListarVeiculosDisponiveis() {
	        armazenamento.ListarVeiculos();
	    }
}
