package gerenciamento.com.br;

import Banco.Armazenamento;
import Banco.ArquivoArmazentamento;
import Banco.BancodeDadosArmazenamento;
import Entities.Concessionaria;
import Entities.*;
import java.util.Scanner;


// PARA FUNCIONAR COM O BANCO MYSQL TROQUE O USUARIO E SENHA NO ARQUVIO BANCODEDADOSARMAZENAMENTO

public class program {
    public static void main(String[] args) {
      
        Scanner sc = new Scanner(System.in);
        int esc = 0;
        
        do {
            System.out.println("1-Cadastrar veiculo no banco de dados");
            System.out.println("2-Cadastrar veiculo no arquivo.csv");
            System.out.println("3-Recuperar veiculo pelo ID banco de dados");
            System.out.println("4-Recuperar veiculo pelo ID arquivo.csv");
            System.out.println("5-Listar veiculos banco de dados");
            System.out.println("6-Listar veiculos arquivo.csv");
            System.out.println("7-Sair");
            System.out.println("Digite sua opção de escolha");
            esc = sc.nextInt();
            
            switch(esc) {
            	case 1:
            		AdicionaVeiculoBanco(sc);
            		break;
            	case 2:
            		AdicionaVeiculoArquvio(sc);
            		break;
            	case 3:
            		System.out.println("Digite o ID que você deseja recuperar");
            		Scanner IDBanco = new Scanner(System.in);
            		recuperaIDbanco(IDBanco.nextInt());
            		IDBanco.close();
            	case 4:
            		System.out.println("Digite o ID que você deseja recuperar");
            		Scanner IDArquivo = new Scanner(System.in);
            		recuperaIDbanco(IDArquivo.nextInt());
            	case 5:
            		System.out.println("Veiculos dentro do banco de dados MySQL");
            		ListaVeiculosBanco();
            	case 6:
            		System.out.println("Veiculos dentro do arquvio veiculos.csv");
            		ListaVeiculosArquivos();
            }
        }while(esc != 7);
                
        
        return;
    }
    
    public static void AdicionaVeiculoBanco(Scanner sc) {
    	Armazenamento banco = new BancodeDadosArmazenamento();
		Concessionaria conc = new Concessionaria(banco);
		System.out.println("Cadastrando no banco de dados");
		int opc = 1;
		System.out.println("Digite qual será o tipo do veículo: 1 - Carro 2 - Moto");
		opc = sc.nextInt();
		if(opc == 1) {
			Carro carro = new Carro();
			System.out.println("Digite a marca do carro");
			carro.setMarca(sc.next());
			carro.setModelo(sc.next());
			carro.setAno_Fabric(sc.next());
			carro.setPreco(sc.nextDouble());
			carro.setNumPortas(sc.nextInt());
			
			conc.AdicionaVeiculoAoEstoque(carro);
			
		}else if(opc == 2) {
			Moto moto = new Moto();
			System.out.println("Digite a marca do moto");
			moto.setMarca(sc.next());
			moto.setModelo(sc.next());
			moto.setAno_Fabric(sc.next());
			moto.setPreco(sc.nextDouble());
			moto.setCilindradas(sc.nextInt());
			conc.AdicionaVeiculoAoEstoque(moto);
			
		}
    }
    
    private static void AdicionaVeiculoArquvio(Scanner sc) {
    	Armazenamento arquivo = new ArquivoArmazentamento();
		Concessionaria conc = new Concessionaria(arquivo);
		System.out.println("Cadstrando por arquivo");
		int opc = 1;
		System.out.println("Digite qual será o tipo do veículo: 1 - Carro 2 - Moto");
		opc = sc.nextInt();
		if(opc == 1) {
			System.out.println("Digite a marca do carro");
			Carro carro = new Carro();
			carro.setMarca(sc.next());
			carro.setModelo(sc.next());
			carro.setAno_Fabric(sc.next());
			carro.setPreco(sc.nextDouble());
			carro.setNumPortas(sc.nextInt());
			
			conc.AdicionaVeiculoAoEstoque(carro);
			
		}else if(opc == 2) {
			Moto moto = new Moto();
			System.out.println("Digite a marca do moto");
			moto.setMarca(sc.next());
			moto.setModelo(sc.next());
			moto.setAno_Fabric(sc.next());
			moto.setPreco(sc.nextDouble());
			moto.setCilindradas(sc.nextInt());
			conc.AdicionaVeiculoAoEstoque(moto);
		}
    }
    
    
    public static void recuperaIDbanco(int id) {
        Armazenamento Arquivo = new BancodeDadosArmazenamento();
        Concessionaria concessionaria = new Concessionaria(Arquivo);
        concessionaria.RecuperaInformacoesVeiculo(id);
    }
    
    public static void recuperaIDArquivoo(int id) {
        Armazenamento Arquivo = new ArquivoArmazentamento();
        Concessionaria concessionaria = new Concessionaria(Arquivo);
        concessionaria.RecuperaInformacoesVeiculo(id);
    }
    
    public static void ListaVeiculosBanco() {
        Armazenamento Arquivo = new BancodeDadosArmazenamento();
        Concessionaria concessionaria = new Concessionaria(Arquivo);
        concessionaria.ListarVeiculosDisponiveis();
    }
    
    public static void ListaVeiculosArquivos() {
        Armazenamento Arquivo = new ArquivoArmazentamento();
        Concessionaria concessionaria = new Concessionaria(Arquivo);
        concessionaria.ListarVeiculosDisponiveis();
    }
   
}
