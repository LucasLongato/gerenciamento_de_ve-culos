package gerenciamento.com.br;

public class Moto extends Veiculo{
		private int Cilindradas;

		public int getCilindradas() {
			return Cilindradas;
		}

		public void setCilindradas(int cilindradas) {
			Cilindradas = cilindradas;
		}
		
}
